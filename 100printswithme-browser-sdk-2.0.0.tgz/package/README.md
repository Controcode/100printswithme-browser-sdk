# 100PrintsWithMe Browser SDK

[![npm version](https://img.shields.io/npm/v/%40100printswithme%2Fbrowser-sdk)](https://www.npmjs.com/package/@100printswithme/browser-sdk)
[![license](https://img.shields.io/npm/l/%40100printswithme%2Fbrowser-sdk)](./LICENSE)
[![TypeScript](https://img.shields.io/badge/TypeScript-ready-3178c6)](https://www.typescriptlang.org/)

Render 100PrintsWithMe templates as PNG, JPEG, raster PDF, or vector PDF directly in a modern browser. The v2 API handles template loading, variable replacement, fonts, rendering, downloads, and object URL cleanup behind one small class.

## Features

- Browser-side PNG, JPEG, PDF, and vector PDF rendering
- Front and back template support
- Typed TypeScript API
- Direct rendering into an `<img>` element
- Built-in download helpers
- Deterministic platform and custom font loading
- ESM package and standalone UMD bundle
- Legacy `BrowserSDK` compatibility for v1 integrations

## Installation

```bash
npm install @100printswithme/browser-sdk
```

```bash
pnpm add @100printswithme/browser-sdk
```

```bash
yarn add @100printswithme/browser-sdk
```

The SDK runs in the browser and requires Canvas, Fetch, Blob, and object URL support.

## Quick start

```ts
import { HundredPrints } from "@100printswithme/browser-sdk";

const prints = new HundredPrints({
  publishableKey: "pk_live_xxx"
});

const image = await prints.png({
  templateId: "tpl_123",
  data: {
    Name: "Rishabh Dev",
    Role: "Chief Scientist"
  },
  side: "front",
  quality: "high"
});

document.querySelector<HTMLImageElement>("#preview")!.src = image.url;
```

Keys in `data` must match the dynamic fields configured in the template. Use a publishable browser key; never expose a secret key in client-side code.

`image.url` is a local object URL. It works for browser previews and downloads, but it is not a permanent public URL. Call `image.revoke()` after the page no longer needs it.

## API

### Create a client

```ts
const prints = new HundredPrints({
  publishableKey: "pk_live_xxx",
  // baseUrl: "https://api.example.com" // optional self-hosted API origin
});
```

Create the client once and reuse it so template and font caches remain effective.

### PNG and JPEG

Images render exactly one side. `side` is required and accepts `"front"` or `"back"`.

```ts
const png = await prints.png({
  templateId: "tpl_123",
  data: { Name: "Rishabh Dev" },
  side: "front",
  quality: "high"
});

const jpeg = await prints.jpeg({
  templateId: "tpl_123",
  data: { Name: "Rishabh Dev" },
  side: "back",
  quality: "standard"
});

png.download("front.png");
jpeg.download("back.jpg");
```

Image results provide `format`, `blob`, `url`, `width`, `height`, `side`, `download()`, and `revoke()`.

### PDF

PDF output renders the front by default. Set `includeBack: true` to add the back as a second page when the template has one.

```ts
const pdf = await prints.pdf({
  templateId: "tpl_123",
  data: { Name: "Rishabh Dev" },
  includeBack: true,
  quality: "ultra"
});

pdf.download("document.pdf");
```

For selectable text and vector artwork, use the vector PDF renderer:

```ts
const pdf = await prints.vectorPdf({
  templateId: "tpl_123",
  data: { Name: "Rishabh Dev" },
  includeBack: true
});

pdf.download("print-ready.pdf");
```

PDF results provide `format`, `blob`, `url`, `pages`, `download()`, and `revoke()`.

### Generic render

`render()` accepts a discriminated output object. TypeScript requires `side` for images and offers `includeBack` for PDFs.

```ts
const result = await prints.render({
  templateId: "tpl_123",
  data: { Name: "Rishabh Dev" },
  output: {
    format: "png",
    side: "front",
    quality: "high"
  }
});
```

Supported formats are `png`, `jpeg`, `pdf`, and `vector-pdf`.

### Render into an image

`renderTo()` accepts a CSS selector or an `HTMLImageElement`. It supports PNG and JPEG output.

```html
<img id="preview" alt="Rendered template">
```

```ts
const result = await prints.renderTo("#preview", {
  templateId: "tpl_123",
  data: { Name: "Rishabh Dev" },
  output: {
    format: "png",
    side: "front",
    quality: "high"
  }
});

// Run this when the image is no longer displayed.
result.revoke();
```

### One-step download

```ts
await prints.download({
  templateId: "tpl_123",
  data: { Name: "Rishabh Dev" },
  output: {
    format: "pdf",
    includeBack: true,
    quality: "high"
  },
  filename: "document.pdf"
});
```

This helper cleans up its temporary object URL after starting the download.

## Quality levels

| Quality | Intended use |
| --- | --- |
| `draft` | Fast previews |
| `standard` | Normal screen output |
| `high` | High-resolution output |
| `ultra` | Maximum-resolution print output |

## Script tag and CDN

The UMD build exposes `HundredPrints` directly on `window`.

```html
<script src="https://cdn.jsdelivr.net/npm/@100printswithme/browser-sdk@2.0.0/dist/100prints-sdk.umd.js"></script>

<img id="preview" alt="Rendered template">

<script>
  const prints = new HundredPrints({ publishableKey: "pk_live_xxx" });

  prints.renderTo("#preview", {
    templateId: "tpl_123",
    data: { Name: "Rishabh Dev" },
    output: {
      format: "png",
      side: "front",
      quality: "high"
    }
  }).catch(console.error);
</script>
```

Serve pages over HTTP or HTTPS. Opening an integration through `file://` prevents reliable API and font requests.

## Font handling

Fonts resolve before drawing in this order:

1. Explicit template or custom font URL
2. 100PrintsWithMe platform font library
3. Google Fonts for families outside the platform library
4. Inter, the platform default
5. Browser `sans-serif`

Known platform fonts use absolute 100PrintsWithMe asset URLs, so the SDK works when embedded on another origin. Recoverable platform or Google font failures emit a warning and continue with a fallback. An explicitly supplied custom font URL retains strict behavior and raises `FONT_LOAD_FAILED` if it cannot load.

## Error handling

SDK failures reject with `HundredPrintsError`. The error contains a stable `code`, a readable message, and the original `cause` when available.

```ts
import {
  HundredPrints,
  HundredPrintsError
} from "@100printswithme/browser-sdk";

try {
  await prints.png({
    templateId: "tpl_123",
    data: {},
    side: "front"
  });
} catch (error) {
  if (error instanceof HundredPrintsError) {
    console.error(error.code, error.message, error.cause);
  }
}
```

Error codes include `AUTH_INVALID`, `TEMPLATE_NOT_FOUND`, `INVALID_INPUT`, `UNSUPPORTED_FORMAT`, `UNSUPPORTED_SIDE`, `INVALID_TARGET`, `FONT_LOAD_FAILED`, `RENDER_FAILED`, and `DOWNLOAD_FAILED`.

## Migrating from v1

Version 2 introduces `HundredPrints` as the recommended public API:

- Constructor option `key` becomes `publishableKey`.
- Render input `payload` becomes `data`.
- PNG and JPEG require an explicit `side`.
- PDFs use `includeBack`.
- Results include an object URL plus `download()` and `revoke()` helpers.

The original `BrowserSDK` export remains available for existing integrations:

```ts
import { BrowserSDK } from "@100printswithme/browser-sdk";

const sdk = new BrowserSDK({ key: "pk_live_xxx" });

const { blob } = await sdk.render({
  templateId: "tpl_123",
  payload: { Name: "Rishabh Dev" },
  format: "pdf"
});
```

New integrations should use `HundredPrints`.

## Browser support

The package targets ES2020 and current versions of Chrome, Edge, Firefox, and Safari. Rendering requires a browser DOM and is not intended for Node.js server-side rendering. In frameworks with server rendering, import and call the SDK from client-side code.

## Development

```bash
npm install
npm test
npm run build
```

The script-tag example is available at [`examples/script-tag`](./examples/script-tag/index.html). After building, run `npm run dev` and open `http://localhost:5173/examples/script-tag/`.

## License

[MIT](./LICENSE) © 2026 100PrintsWithMe.
